const jokes = [
  "Why don't scientists trust atoms? Because they make up everything!",
  "Why was the math book sad? It had too many problems.",
  "Why did the computer catch a cold? It left its Windows open!",
  "I told my wife she was drawing her eyebrows too high. She looked surprised.",
  "Why can't your nose be 12 inches long? Because then it would be a foot!"
];

function getJoke() {
  const jokeElement = document.getElementById('joke');
  const randomIndex = Math.floor(Math.random() * jokes.length);
  jokeElement.textContent = jokes[randomIndex];
}