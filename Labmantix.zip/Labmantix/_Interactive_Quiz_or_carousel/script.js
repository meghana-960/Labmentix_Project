const questions = [
  {
    question: "What does HTML stand for?",
    options: ["Hyper Text Markup Language", "Hot Mail", "How To Make Landingpage"],
    answer: "Hyper Text Markup Language"
  },
  {
    question: "What is the correct CSS syntax to change text color to red?",
    options: ["color: red;", "text-color: red;", "fontcolor: red;"],
    answer: "color: red;"
  },
  {
    question: "Which language is used for web apps?",
    options: ["PHP", "Python", "JavaScript"],
    answer: "JavaScript"
  }
];

let currentIndex = 0;
let score = 0;

function loadQuestion() {
  const q = questions[currentIndex];
  document.getElementById("question").textContent = q.question;

  const optionsHTML = q.options.map(opt => `
    <label>
      <input type="radio" name="option" value="${opt}" />
      ${opt}
    </label>
  `).join('');

  document.getElementById("options").innerHTML = optionsHTML;
}

document.getElementById("nextBtn").addEventListener("click", () => {
  const selected = document.querySelector('input[name="option"]:checked');

  if (selected) {
    if (selected.value === questions[currentIndex].answer) {
      score++;
    }
    currentIndex++;

    if (currentIndex < questions.length) {
      loadQuestion();
    } else {
      document.getElementById("quiz-box").innerHTML =
        `<h2>🎉 Quiz Completed!</h2>
         <p>Your Score: <strong>${score} / ${questions.length}</strong></p>`;
    }
  } else {
    alert("Please select an option!");
  }
});

window.onload = loadQuestion;